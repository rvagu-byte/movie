"""
netflix_eda — source package
"""
