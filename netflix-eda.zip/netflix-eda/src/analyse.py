"""
src/analyse.py
--------------
Aggregation helpers that return tidy DataFrames ready for plotting.
"""

from __future__ import annotations

import pandas as pd

from src.clean import explode_genres, explode_countries


# ── Content split ────────────────────────────────────────────────────────────

def content_type_counts(df: pd.DataFrame) -> pd.Series:
    """Return value counts for Movies vs TV Shows."""
    return df["type"].value_counts()


# ── Time series ───────────────────────────────────────────────────────────────

def titles_added_per_year(df: pd.DataFrame) -> pd.Series:
    """Number of titles added to Netflix per calendar year."""
    return (
        df.dropna(subset=["year_added"])
        .groupby("year_added")
        .size()
        .rename("count")
        .sort_index()
    )


def titles_released_per_year(df: pd.DataFrame, top_n: int = 16) -> pd.Series:
    """Number of titles by original release year (most recent *top_n* years)."""
    counts = (
        df.dropna(subset=["release_year"])
        .groupby("release_year")
        .size()
        .rename("count")
        .sort_index()
    )
    return counts.iloc[-top_n:]


# ── Geography ─────────────────────────────────────────────────────────────────

def top_countries(df: pd.DataFrame, n: int = 10) -> pd.Series:
    """Top *n* content-producing countries (titles may have multiple)."""
    return (
        explode_countries(df)["country"]
        .value_counts()
        .head(n)
    )


# ── Ratings ───────────────────────────────────────────────────────────────────

def rating_distribution(df: pd.DataFrame) -> pd.Series:
    """Value counts for each content rating, excluding nulls."""
    return (
        df.dropna(subset=["rating"])
        .groupby("rating")
        .size()
        .rename("count")
        .sort_values(ascending=False)
    )


# ── Genres ────────────────────────────────────────────────────────────────────

def top_genres(df: pd.DataFrame, n: int = 10) -> pd.Series:
    """Top *n* genre tags across the entire catalogue."""
    return (
        explode_genres(df)["genre"]
        .value_counts()
        .head(n)
    )


# ── Duration ─────────────────────────────────────────────────────────────────

def movie_durations(df: pd.DataFrame) -> pd.Series:
    """Duration (minutes) series for movies only, with nulls dropped."""
    return (
        df.loc[df["type"] == "Movie", "duration_int"]
        .dropna()
        .astype(int)
        .rename("minutes")
    )


# ── Summary stats ─────────────────────────────────────────────────────────────

def print_summary_stats(df: pd.DataFrame) -> None:
    """Print a human-readable EDA summary to stdout."""
    print("\n" + "=" * 55)
    print("EDA SUMMARY STATISTICS")
    print("=" * 55)

    print(f"\n  Total titles     : {len(df):,}")
    for t, grp in df.groupby("type"):
        pct = len(grp) / len(df) * 100
        print(f"    {t:<12}: {len(grp):,}  ({pct:.1f} %)")

    print(f"\n  Date range added : "
          f"{df['year_added'].min()} – {df['year_added'].max()}")
    peak_year = titles_added_per_year(df).idxmax()
    print(f"  Peak addition yr : {peak_year}")

    print(f"\n  Unique countries : {df['country'].nunique()}")
    print(f"  Unique ratings   : {df['rating'].nunique()}")
    print(f"  Unique genres    : {len(explode_genres(df)['genre'].unique())}")

    durations = movie_durations(df)
    print(f"\n  Movie duration   :")
    print(f"    Mean  : {durations.mean():.0f} min")
    print(f"    Median: {durations.median():.0f} min")
    print(f"    Min   : {durations.min()} min")
    print(f"    Max   : {durations.max()} min")
    print("=" * 55)
