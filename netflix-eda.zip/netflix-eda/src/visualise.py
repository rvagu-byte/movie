"""
src/visualise.py
----------------
All visualisation functions. Each returns a ``matplotlib.figure.Figure``
and optionally saves it to *output_dir*.
"""

from __future__ import annotations

import os
from typing import Optional

import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import seaborn as sns
import pandas as pd
import numpy as np

from src.analyse import (
    content_type_counts,
    titles_added_per_year,
    titles_released_per_year,
    top_countries,
    rating_distribution,
    top_genres,
    movie_durations,
)

# ── Global style ──────────────────────────────────────────────────────────────

PALETTE_BLUE   = "#3266ad"
PALETTE_TEAL   = "#1d9e75"
PALETTE_CORAL  = "#d85a30"
PALETTE_PURPLE = "#8a5bbf"
PALETTE_GRAY   = "#888780"

sns.set_theme(style="whitegrid", palette="muted", font_scale=1.05)
plt.rcParams.update({
    "figure.dpi": 120,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.titlesize": 13,
    "axes.titleweight": "medium",
    "axes.labelsize": 11,
})


def _save(fig: plt.Figure, name: str, output_dir: Optional[str]) -> None:
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
        path = os.path.join(output_dir, f"{name}.png")
        fig.savefig(path, bbox_inches="tight")
        print(f"  Saved → {path}")


# ── 1. Content type split ─────────────────────────────────────────────────────

def plot_content_type(
    df: pd.DataFrame,
    output_dir: Optional[str] = None,
) -> plt.Figure:
    """Doughnut chart: Movies vs TV Shows."""
    counts = content_type_counts(df)
    fig, ax = plt.subplots(figsize=(5, 5))
    colors = [PALETTE_BLUE, PALETTE_TEAL]
    wedges, texts, autotexts = ax.pie(
        counts,
        labels=counts.index,
        autopct="%1.1f%%",
        colors=colors,
        startangle=90,
        wedgeprops={"width": 0.55, "edgecolor": "white"},
    )
    for at in autotexts:
        at.set_fontsize(11)
    ax.set_title("Content Type Split", pad=16)
    fig.tight_layout()
    _save(fig, "01_content_type", output_dir)
    return fig


# ── 2. Titles added per year ──────────────────────────────────────────────────

def plot_titles_added(
    df: pd.DataFrame,
    output_dir: Optional[str] = None,
) -> plt.Figure:
    """Bar chart: how many titles Netflix added each year."""
    data = titles_added_per_year(df)
    # Focus on years with meaningful volume
    data = data[data.index >= 2015]

    fig, ax = plt.subplots(figsize=(9, 4))
    bars = ax.bar(data.index.astype(str), data.values, color=PALETTE_BLUE, width=0.6)

    for bar in bars:
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + 30,
            f"{int(bar.get_height()):,}",
            ha="center", va="bottom", fontsize=9, color=PALETTE_GRAY,
        )

    ax.set_title("Titles Added to Netflix per Year")
    ax.set_xlabel("Year")
    ax.set_ylabel("Number of titles")
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{int(x):,}"))
    ax.set_ylim(0, data.max() * 1.18)
    fig.tight_layout()
    _save(fig, "02_titles_added_per_year", output_dir)
    return fig


# ── 3. Top countries ──────────────────────────────────────────────────────────

def plot_top_countries(
    df: pd.DataFrame,
    n: int = 10,
    output_dir: Optional[str] = None,
) -> plt.Figure:
    """Horizontal bar chart: top content-producing countries."""
    data = top_countries(df, n=n).sort_values()

    fig, ax = plt.subplots(figsize=(8, 5))
    colors = sns.color_palette("Blues_r", len(data))
    bars = ax.barh(data.index, data.values, color=colors, edgecolor="none")

    for bar in bars:
        ax.text(
            bar.get_width() + 30,
            bar.get_y() + bar.get_height() / 2,
            f"{int(bar.get_width()):,}",
            va="center", fontsize=9, color=PALETTE_GRAY,
        )

    ax.set_title(f"Top {n} Content-Producing Countries")
    ax.set_xlabel("Number of titles")
    ax.set_xlim(0, data.max() * 1.18)
    ax.tick_params(axis="y", labelsize=10)
    fig.tight_layout()
    _save(fig, "03_top_countries", output_dir)
    return fig


# ── 4. Ratings distribution ───────────────────────────────────────────────────

def plot_ratings(
    df: pd.DataFrame,
    output_dir: Optional[str] = None,
) -> plt.Figure:
    """Horizontal bar chart: content rating frequency."""
    data = rating_distribution(df).sort_values()

    fig, ax = plt.subplots(figsize=(8, 5))
    colors = sns.color_palette("Greens_r", len(data))
    bars = ax.barh(data.index, data.values, color=colors, edgecolor="none")

    for bar in bars:
        ax.text(
            bar.get_width() + 20,
            bar.get_y() + bar.get_height() / 2,
            f"{int(bar.get_width()):,}",
            va="center", fontsize=9, color=PALETTE_GRAY,
        )

    ax.set_title("Content Ratings Distribution")
    ax.set_xlabel("Number of titles")
    ax.set_xlim(0, data.max() * 1.18)
    fig.tight_layout()
    _save(fig, "04_ratings_distribution", output_dir)
    return fig


# ── 5. Top genres ─────────────────────────────────────────────────────────────

def plot_top_genres(
    df: pd.DataFrame,
    n: int = 12,
    output_dir: Optional[str] = None,
) -> plt.Figure:
    """Horizontal bar chart: top genre tags."""
    data = top_genres(df, n=n).sort_values()

    fig, ax = plt.subplots(figsize=(8, 6))
    colors = sns.color_palette("Purples_r", len(data))
    bars = ax.barh(data.index, data.values, color=colors, edgecolor="none")

    for bar in bars:
        ax.text(
            bar.get_width() + 20,
            bar.get_y() + bar.get_height() / 2,
            f"{int(bar.get_width()):,}",
            va="center", fontsize=9, color=PALETTE_GRAY,
        )

    ax.set_title(f"Top {n} Genre Tags")
    ax.set_xlabel("Number of titles")
    ax.set_xlim(0, data.max() * 1.18)
    fig.tight_layout()
    _save(fig, "05_top_genres", output_dir)
    return fig


# ── 6. Movie duration histogram ───────────────────────────────────────────────

def plot_duration_histogram(
    df: pd.DataFrame,
    output_dir: Optional[str] = None,
) -> plt.Figure:
    """Histogram of movie runtimes in minutes."""
    durations = movie_durations(df)

    fig, ax = plt.subplots(figsize=(8, 4))
    ax.hist(
        durations,
        bins=range(0, int(durations.max()) + 30, 15),
        color=PALETTE_CORAL,
        edgecolor="white",
        linewidth=0.5,
    )

    ax.axvline(durations.median(), color=PALETTE_GRAY, linestyle="--", linewidth=1.2,
               label=f"Median: {int(durations.median())} min")
    ax.axvline(durations.mean(), color=PALETTE_BLUE, linestyle=":", linewidth=1.2,
               label=f"Mean: {int(durations.mean())} min")

    ax.set_title("Movie Duration Distribution")
    ax.set_xlabel("Runtime (minutes)")
    ax.set_ylabel("Number of movies")
    ax.legend(fontsize=10)
    ax.set_xlim(0, 240)
    fig.tight_layout()
    _save(fig, "06_movie_duration_histogram", output_dir)
    return fig


# ── 7. Release year trend ─────────────────────────────────────────────────────

def plot_release_year_trend(
    df: pd.DataFrame,
    output_dir: Optional[str] = None,
) -> plt.Figure:
    """Line chart: number of titles by release year."""
    data = titles_released_per_year(df, top_n=16)

    fig, ax = plt.subplots(figsize=(10, 4))
    ax.fill_between(data.index.astype(str), data.values,
                    alpha=0.15, color=PALETTE_BLUE)
    ax.plot(data.index.astype(str), data.values,
            color=PALETTE_BLUE, linewidth=2, marker="o", markersize=5)

    ax.set_title("Titles by Original Release Year")
    ax.set_xlabel("Release year")
    ax.set_ylabel("Number of titles")
    ax.tick_params(axis="x", rotation=35)
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{int(x):,}"))
    fig.tight_layout()
    _save(fig, "07_release_year_trend", output_dir)
    return fig


# ── 8. All-in-one summary dashboard ──────────────────────────────────────────

def plot_dashboard(
    df: pd.DataFrame,
    output_dir: Optional[str] = None,
) -> plt.Figure:
    """4-panel summary figure combining the most important charts."""
    fig = plt.figure(figsize=(16, 12))
    fig.suptitle("Netflix Titles — EDA Summary Dashboard", fontsize=16, fontweight="medium", y=0.98)

    # Panel 1 — content type doughnut
    ax1 = fig.add_subplot(2, 3, 1)
    counts = content_type_counts(df)
    ax1.pie(
        counts,
        labels=counts.index,
        autopct="%1.0f%%",
        colors=[PALETTE_BLUE, PALETTE_TEAL],
        startangle=90,
        wedgeprops={"width": 0.55, "edgecolor": "white"},
    )
    ax1.set_title("Content Type", fontsize=11)

    # Panel 2 — titles added per year (bar)
    ax2 = fig.add_subplot(2, 3, 2)
    added = titles_added_per_year(df)
    added = added[added.index >= 2015]
    ax2.bar(added.index.astype(str), added.values, color=PALETTE_BLUE, width=0.6)
    ax2.set_title("Titles Added per Year", fontsize=11)
    ax2.tick_params(axis="x", rotation=35)
    ax2.spines["top"].set_visible(False)
    ax2.spines["right"].set_visible(False)

    # Panel 3 — top 8 countries
    ax3 = fig.add_subplot(2, 3, 3)
    countries = top_countries(df, n=8).sort_values()
    ax3.barh(countries.index, countries.values,
             color=sns.color_palette("Blues_r", len(countries)), edgecolor="none")
    ax3.set_title("Top 8 Countries", fontsize=11)
    ax3.spines["top"].set_visible(False)
    ax3.spines["right"].set_visible(False)
    ax3.tick_params(axis="y", labelsize=9)

    # Panel 4 — ratings
    ax4 = fig.add_subplot(2, 3, 4)
    ratings = rating_distribution(df).head(8).sort_values()
    ax4.barh(ratings.index, ratings.values,
             color=sns.color_palette("Greens_r", len(ratings)), edgecolor="none")
    ax4.set_title("Top 8 Ratings", fontsize=11)
    ax4.spines["top"].set_visible(False)
    ax4.spines["right"].set_visible(False)

    # Panel 5 — top 8 genres
    ax5 = fig.add_subplot(2, 3, 5)
    genres = top_genres(df, n=8).sort_values()
    ax5.barh(genres.index, genres.values,
             color=sns.color_palette("Purples_r", len(genres)), edgecolor="none")
    ax5.set_title("Top 8 Genres", fontsize=11)
    ax5.spines["top"].set_visible(False)
    ax5.spines["right"].set_visible(False)
    ax5.tick_params(axis="y", labelsize=9)

    # Panel 6 — duration histogram
    ax6 = fig.add_subplot(2, 3, 6)
    durations = movie_durations(df)
    ax6.hist(durations, bins=range(0, 211, 20), color=PALETTE_CORAL,
             edgecolor="white", linewidth=0.5)
    ax6.axvline(durations.median(), color=PALETTE_GRAY, linestyle="--",
                linewidth=1, label=f"Median {int(durations.median())} min")
    ax6.set_title("Movie Duration (min)", fontsize=11)
    ax6.set_xlim(0, 210)
    ax6.legend(fontsize=9)
    ax6.spines["top"].set_visible(False)
    ax6.spines["right"].set_visible(False)

    fig.tight_layout(rect=[0, 0, 1, 0.96])
    _save(fig, "00_dashboard", output_dir)
    return fig
