"""
tests/test_analyse.py
---------------------
Unit tests for src/analyse.py  (stdlib unittest)
"""

import unittest
import pandas as pd

from src.load import load_data
from src.clean import clean_data
from src.analyse import (
    content_type_counts,
    titles_added_per_year,
    top_countries,
    rating_distribution,
    top_genres,
    movie_durations,
)


def setUpModule():
    global DF
    DF = clean_data(load_data("data/netflix_titles.csv"))


class TestContentTypeCounts(unittest.TestCase):

    def test_has_movie_and_tv(self):
        counts = content_type_counts(DF)
        self.assertIn("Movie", counts.index)
        self.assertIn("TV Show", counts.index)

    def test_movies_greater_than_tv(self):
        counts = content_type_counts(DF)
        self.assertGreater(counts["Movie"], counts["TV Show"])


class TestTitlesAddedPerYear(unittest.TestCase):

    def test_returns_series(self):
        self.assertIsInstance(titles_added_per_year(DF), pd.Series)

    def test_2019_is_peak(self):
        result = titles_added_per_year(DF)
        self.assertEqual(result.idxmax(), 2019)


class TestTopCountries(unittest.TestCase):

    def test_us_is_top(self):
        result = top_countries(DF, n=5)
        self.assertEqual(result.index[0], "United States")

    def test_returns_n_results(self):
        self.assertEqual(len(top_countries(DF, n=7)), 7)


class TestRatingDistribution(unittest.TestCase):

    def test_tv_ma_is_most_common(self):
        result = rating_distribution(DF)
        self.assertEqual(result.index[0], "TV-MA")

    def test_no_bad_ratings(self):
        result = rating_distribution(DF)
        self.assertNotIn("74 min", result.index)


class TestTopGenres(unittest.TestCase):

    def test_returns_series(self):
        self.assertIsInstance(top_genres(DF), pd.Series)

    def test_top_n_respected(self):
        self.assertEqual(len(top_genres(DF, n=5)), 5)


class TestMovieDurations(unittest.TestCase):

    def test_all_positive(self):
        self.assertTrue((movie_durations(DF) > 0).all())

    def test_median_in_range(self):
        median = movie_durations(DF).median()
        self.assertTrue(80 <= median <= 120, f"Unexpected median: {median}")


if __name__ == "__main__":
    unittest.main()
