"""
tests/test_clean.py
-------------------
Unit tests for src/clean.py  (stdlib unittest)
"""

import unittest
import pandas as pd

from src.clean import clean_data, explode_genres, explode_countries


def _sample_df():
    return pd.DataFrame({
        "show_id":      ["s1", "s2", "s3"],
        "type":         ["Movie", "TV Show", "Movie"],
        "title":        ["Film A", "Show B", "Film C"],
        "director":     ["Dir A", None, "Dir C"],
        "cast":         [None, "Actor X", "Actor Y"],
        "country":      ["United States", "India, United Kingdom", None],
        "date_added":   ["September 25, 2021", "March 1, 2020", None],
        "release_year": [2020, 2019, 2018],
        "rating":       ["PG-13", "74 min", "TV-MA"],
        "duration":     ["90 min", "2 Seasons", "120 min"],
        "listed_in":    ["Dramas, Comedies", "Crime TV Shows, Thrillers", "Action & Adventure"],
        "description":  ["Desc A", "Desc B", "Desc C"],
    })


class TestCleanData(unittest.TestCase):

    def setUp(self):
        self.raw = _sample_df()
        self.df  = clean_data(self.raw)

    def test_returns_copy(self):
        self.assertIsNot(self.df, self.raw)

    def test_year_added_extracted(self):
        self.assertIn("year_added", self.df.columns)
        self.assertEqual(self.df.loc[0, "year_added"], 2021)

    def test_month_added_extracted(self):
        self.assertEqual(self.df.loc[0, "month_added"], 9)

    def test_bad_rating_becomes_na(self):
        self.assertTrue(pd.isna(self.df.loc[1, "rating"]))

    def test_valid_rating_preserved(self):
        self.assertEqual(self.df.loc[0, "rating"], "PG-13")

    def test_duration_int_movie(self):
        self.assertEqual(self.df.loc[0, "duration_int"], 90)

    def test_duration_int_tv_show(self):
        self.assertEqual(self.df.loc[1, "duration_int"], 2)


class TestExplodeGenres(unittest.TestCase):

    def setUp(self):
        self.df = clean_data(_sample_df())

    def test_multiple_genres_exploded(self):
        exploded = explode_genres(self.df)
        s1_genres = exploded[exploded["show_id"] == "s1"]["genre"].tolist()
        self.assertIn("Dramas", s1_genres)
        self.assertIn("Comedies", s1_genres)

    def test_no_null_genres(self):
        self.assertTrue(explode_genres(self.df)["genre"].notna().all())


class TestExplodeCountries(unittest.TestCase):

    def setUp(self):
        self.df = clean_data(_sample_df())

    def test_multi_country_exploded(self):
        exploded = explode_countries(self.df)
        s2 = exploded[exploded["show_id"] == "s2"]["country"].tolist()
        self.assertIn("India", s2)
        self.assertIn("United Kingdom", s2)

    def test_null_country_dropped(self):
        self.assertTrue(explode_countries(self.df)["country"].notna().all())


if __name__ == "__main__":
    unittest.main()
