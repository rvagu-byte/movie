"""
tests/test_load.py
------------------
Unit tests for src/load.py
"""

import os
import unittest
import pandas as pd

from src.load import load_data, _validate_columns


SAMPLE_CSV = os.path.join("data", "netflix_titles.csv")


class TestLoadData(unittest.TestCase):

    def test_returns_dataframe(self):
        df = load_data(SAMPLE_CSV)
        self.assertIsInstance(df, pd.DataFrame)

    def test_row_count(self):
        df = load_data(SAMPLE_CSV)
        self.assertGreater(len(df), 8000)

    def test_expected_columns_present(self):
        df = load_data(SAMPLE_CSV)
        required = {"show_id", "type", "title", "release_year", "listed_in"}
        self.assertTrue(required.issubset(set(df.columns)))

    def test_file_not_found(self):
        with self.assertRaises(FileNotFoundError):
            load_data("nonexistent/path/data.csv")

    def test_missing_column_raises(self):
        df = pd.DataFrame({"show_id": [1], "type": ["Movie"]})
        with self.assertRaises(ValueError):
            _validate_columns(df)


if __name__ == "__main__":
    unittest.main()
